package com.example.AffordBackEnd.AffordBackEnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AffordBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(AffordBackEndApplication.class, args);
	}

}
