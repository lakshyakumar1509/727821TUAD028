package com.example.AffordBackEnd.AffordBackEnd;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class Controller {

    @Autowired
    private ServiceFile service;

    @GetMapping("/getProductDetails")
    public List<Model> getAllProducts() {
        return (List<Model>) service.getAllProducts();
    }

    @GetMapping("/{categoryname}/{n}/products")
    public List<Model> getTopProducts(
            @PathVariable String categoryname,
            @PathVariable  int n,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam Optional<String> sortField,
            @RequestParam Optional<String> sortOrder) {
        return service.getTopProducts(categoryname, n, page, sortField, sortOrder);
    }
    
}
