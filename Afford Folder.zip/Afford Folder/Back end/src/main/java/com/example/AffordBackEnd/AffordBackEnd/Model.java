package com.example.AffordBackEnd.AffordBackEnd;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;


@Entity
@Table(name="dbtable")
public class Model {
    
    String productName;

    @Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
    Long productId;
    String company;
    String category;
    int price;
    int rating;
    int discount;
    String availability;

    public Model() {
    }
    public Model(Long productId,String productName, String company, String category, int price, int rating, int discount,
    String availability) {
        this.productId = productId;
        this.productName = productName;
        this.company = company;
        this.category = category;
        this.price = price;
        this.rating = rating;
        this.discount = discount;
        this.availability = availability;
    }

    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public Long getProductId() {
        return productId;
    }
    public void setProductId(Long productId) {
        this.productId = productId;
    }
    public String getCompany() {
        return company;
    }
    public void setCompany(String company) {
        this.company = company;
    }
    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    public int getPrice() {
        return price;
    }
    public void setPrice(int price) {
        this.price = price;
    }
    public int getRating() {
        return rating;
    }
    public void setRating(int rating) {
        this.rating = rating;
    }
    public int getDiscount() {
        return discount;
    }
    public void setDiscount(int discount) {
        this.discount = discount;
    }
    public String isAvailability() {
        return availability;
    }
    public void setAvailability(String availability) {
        this.availability = availability;
    }
    @Override
    public String toString() {
        return "Model [productName=" + productName + ", company=" + company + ", category=" + category + ", price="
                + price + ", rating=" + rating + ", discount=" + discount + ", availability=" + availability + "]";
    }
    

    
}
