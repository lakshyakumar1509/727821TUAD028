package com.example.AffordBackEnd.AffordBackEnd;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.domain.Pageable;
import java.util.List;

public interface Repository extends JpaRepository<Model, Long>{
    
    List<Model> findByCategory(String category,int n,Pageable pageable);
}
