package com.example.AffordBackEnd.AffordBackEnd;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import java.util.List;
import java.util.Optional;

@Service
public class ServiceFile {
    @Autowired
	  Repository r;

      public Iterable<Model> getAllProducts() {
        return r.findAll();      
  }

  public List<Model> getTopProducts(String categoryname, int n, int page, Optional<String> sortField, Optional<String> sortOrder) {
    Pageable pageable = PageRequest.of(page - 1, n, 
            Sort.by(Sort.Direction.fromString(sortOrder.orElse("asc")), sortField.orElse("productId")));
    return r.findByCategory(categoryname, n, pageable);
}

}
