package com.example.AffordBackEnd.AffordBackEnd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AffordBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
