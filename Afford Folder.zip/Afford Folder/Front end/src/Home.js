import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Home = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
     
        const response = await axios.get('http://localhost:8080/getProductDetails');
        setProducts(response.data);
    };

    fetchData();
  }, []);

  return (
    <div className='product-container'> 
    <h3>DISPLAYING ALL THE PRODUCTS</h3>
      {products.length > 0 && (
        <table>
          <thead>
            <tr>
              {/* Assuming you know the column names from your backend response */}
              <th>Name</th>
              <th>Price</th>
              <th>Rating</th>
              <th>Discount</th>
              <th>Availability</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product.id}>
                <td>{product.productName}</td>
                <td>{product.price}</td>
                <td>{product.rating}</td>
                <td>{product.discount}</td>
                <td>{product.availability}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {products.length === 0 && <p>No products found.</p>}
    </div>
  );
};

export default Home;
